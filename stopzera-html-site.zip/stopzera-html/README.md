# STOPZERA — Site em HTML, CSS e JavaScript

Site portfólio dark, futurista e interativo para **Thiago Santos / STOPZERA**.

## Estrutura

```text
stopzera-html/
├─ index.html
├─ css/
│  └─ style.css
├─ js/
│  └─ main.js
├─ images/
│  ├─ project-1.svg
│  ├─ project-2.svg
│  ├─ project-3.svg
│  └─ project-4.svg
└─ README.md
```

## Como visualizar

Basta abrir o arquivo `index.html` no navegador.

Ou, para um servidor local:

```bash
npx serve .
```

## Como editar

- **Textos:** edite diretamente em `index.html`.
- **Cores, fontes e layout:** edite `css/style.css`.
- **Animações, cursor e partículas:** edite `js/main.js`.
- **Projetos:** troque as imagens em `images/` e altere os cards no `index.html`.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub, por exemplo `stopzera-site`.
2. Envie todos os arquivos desta pasta.
3. Vá em **Settings → Pages**.
4. Em **Source**, escolha `Deploy from a branch`.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve. O site ficará disponível em:
   `https://SEU-USUARIO.github.io/stopzera-site/`

## Comandos Git

```bash
git init
git add .
git commit -m "feat: site STOPZERA em HTML, CSS e JS"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/stopzera-site.git
git push -u origin main
```
